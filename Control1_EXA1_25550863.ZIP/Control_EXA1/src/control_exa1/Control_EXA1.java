/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package control_exa1;
import java.util.Scanner;
/**
 *
 * @author Azul
 */
public class Control_EXA1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int saldo = 5000;
        int pinCorrecto = 1234;
        
        //Pedir PIN
        System.out.print("Ingrese su PIN: ");
        int pin = sc.nextInt();
        
        if (pin != pinCorrecto) {
            System.out.println("Acceso denegado");
        }else{
            //Menu
            System.out.println("Bienvenido al cajero");
            System.out.println("1. Consultar Saldo");
            System.out.println("2. Retirar dinero");
            System.out.println("3. Depositar dinero");
            System.out.print("Elija una opcion: ");
            int opcion = sc.nextInt();
            
            if (opcion == 1) {
                //Consultar Saldo
                System.out.println("Su saldo es: $" + saldo);
                
            } else if (opcion == 2) {
                //Retirar dinero
                System.out.print("Ingrese monto a retirar: ");
                int retiro = sc.nextInt();
                if (retiro > 0 && retiro <= saldo) {
                    saldo -= retiro;
                    System.out.println("Retiro exitoso. Saldo final: $" + saldo);
                } else {
                    System.out.println("Error: monto invalido.");
                }
            
            } else if (opcion == 3) {
                //Depositar dinero
                System.out.print("Ingrese monto a depositar: ");
                int deposito = sc.nextInt();
                if (deposito > 0) {
                    saldo += deposito;
                    System.out.println("Deposito exitoso. Saldo finall: $" + saldo);
                } else {
                    System.out.println("Error: el deposito no puede ser negativo.");
                }
                
            } else{
                System.out.println("Opcion invalida. ");
                }
            }
        }
       
    }
    

