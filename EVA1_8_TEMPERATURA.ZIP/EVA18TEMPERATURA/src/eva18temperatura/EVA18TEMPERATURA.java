/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva18temperatura;

/**
 *
 * @author PC MONSTER HUNTER
 */
public class EVA18TEMPERATURA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double F, C;
        
        F=  300;
        C=  (F-32)*5/9;
        System.out.println("Los grados Fahrenheit= 300 a Celsius es=");
        System.out.println(C);
    }
    
}
