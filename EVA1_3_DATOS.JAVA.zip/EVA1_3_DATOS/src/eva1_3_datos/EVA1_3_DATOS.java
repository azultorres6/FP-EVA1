/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_3_datos;

/**
 *
 * @author Azul
 */
public class EVA1_3_DATOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Nombre del estudiante:");
        System.out.print("Azul Torres:");
        System.out.println("Numero de control:");
        System.out.println("25550863:");
        System.out.print("Edad");
        System.out.println("17:");
        
    }
    
}
