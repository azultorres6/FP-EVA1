/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_4_ejercicio;

/**
 *
 * @author Azul Torres
 */
public class EVA1_4_EJERCICIO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    System.out.print("Empleo: ");
    System.out.println("Ingeniera en sistemas");
    System.out.print("Salario: ");
    System.out.println("$12,500MXN mensuales");
    System.out.print("Horas semana: ");
    System.out.println("48 h/semana");
    System.out.print("Requiere ingles: ");
    System.out.println("true");
    }
    
}
