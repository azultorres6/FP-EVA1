/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_7_area_triangulo;

/**
 *
 * @author Azul
 */
public class EVA1_7_AREA_TRIANGULO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double base,altura,area;//todas son dobles
        base=8;
        altura=6;
        area=(base * altura)/2;
        System.out.println("El area de un triangulo base="+ base+"y altura="+ altura+"es:"+ area);
        System.out.println("area");
    }
    
}
