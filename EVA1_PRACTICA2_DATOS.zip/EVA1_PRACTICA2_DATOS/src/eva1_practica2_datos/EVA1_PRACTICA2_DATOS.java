/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_practica2_datos;

/**
 *
 * @author Azul
 */
public class EVA1_PRACTICA2_DATOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("AZUL TORRES");
        // T"-->CADENA DE TEXTO"
        System.out.println(1000);
        //NUMEROS ENTEROS
        System.out.println(500.3);
        //NUMEROS DECIMALES
        System.out.println(true);
                //VALORES LOGICOS (VERDADERO O FALSO)
                //true false
                System.out.println('c');//CARACTER
                        System.out.println("c");//CADENA DE TEXTO
                        //CARACTERES INDIVIDUALES
                        //COSAS DISTINTAS
                        
    }
    
}
